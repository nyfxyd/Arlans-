"""Проверка фильтров, шорт-листа и парсинга ответа ИИ — без сети.

Запуск: python -m tests.smoke_test
"""
from backend.ai_service import AIServiceError, build_fallback, parse_ai_json
from backend.filtering import apply_hard_rules, load_universities, pick_for_ai
from backend.models import StudentProfile

profile = StudentProfile(
    name="Айгерим", track="both", target_major="Computer Science",
    ent_score=112, ent_subjects=["Математика", "Физика"],
    gpa=4.6, ielts=6.0, sat=0,
    preferred_countries=[], needs_scholarship=True,
    budget_kzt_per_year=3_000_000, career="build",
)

unis = load_universities()
passed, rejected = apply_hard_rules(profile, unis)
print(f"База: {len(unis)} | прошли: {len(passed)} | отсеяно: {len(rejected)}")
for r in rejected[:5]:
    print("  ✗", r.name, "—", r.reason)

short = pick_for_ai(profile, passed)
print("Шорт-лист для ИИ:", ", ".join(u.name for u in short))

result = build_fallback(profile, short)
assert result.insights and result.strengths
print("Fallback:", len(result.insights), "аргументаций,", len(result.strengths), "сильных сторон")

wrapped = "```json\n" + result.model_dump_json() + "\n```"
assert parse_ai_json(wrapped).summary == result.summary
try:
    parse_ai_json("не json")
except AIServiceError as exc:
    print("Битый JSON перехвачен:", str(exc)[:60])

print("SMOKE OK")
