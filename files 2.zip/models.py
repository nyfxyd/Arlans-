"""Pydantic-схемы: профиль, ВУЗ, строгий ответ ИИ."""
from __future__ import annotations

from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class Track(str, Enum):
    KZ = "kz"
    INTERNATIONAL = "international"
    BOTH = "both"


class Teaching(BaseModel):
    practice: float
    research: float
    industry: float


class Weights(BaseModel):
    subjects: float = 1.0
    scores: float = 1.0
    budget: float = 1.0
    vibe: float = 1.0


class Deadlines(BaseModel):
    # В источнике часть дат отсутствует — храним None, а не выдумываем.
    application: Optional[str] = None
    early: Optional[str] = None
    scholarship: Optional[str] = None
    documents: Optional[str] = None


class University(BaseModel):
    id: str
    name: str
    city: str
    country: str
    flag: str = "🎓"
    type: Literal["local", "international"]
    majors: list[str] = Field(default_factory=list)
    careers: list[str] = Field(default_factory=list)
    vibe: list[str] = Field(default_factory=list)
    why: str = ""

    ent_passing_score: Optional[int] = None
    required_subjects: list[str] = Field(default_factory=list)
    ielts_min: Optional[float] = None
    sat_recommended: Optional[int] = None
    gpa_min: Optional[float] = None

    tuition_kzt: int = 0
    rent_kzt: int = 0
    transport_kzt: int = 0
    living_kzt: int = 0
    total_cost_kzt: int = 0
    scholarship: str = ""
    dorm: Optional[bool] = None

    teaching: Optional[Teaching] = None
    weights: Weights = Weights()
    deadlines: Deadlines = Deadlines()

    # Поля из universities_database v2.0
    website: Optional[str] = None
    acceptance_rate: Optional[float] = None
    application_fee: Optional[str] = None
    lang: Optional[str] = None
    ielts_note: Optional[str] = None
    gpa_note: Optional[str] = None
    sat_note: Optional[str] = None
    lor_count: Optional[int] = None
    interview: Optional[str] = None
    visa: Optional[str] = None
    post_study: Optional[str] = None
    blocked_account: Optional[str] = None
    tuition_known: bool = True
    cost_estimated: bool = False
    source: str = "curated"
    data_status: str = "complete"

    @model_validator(mode="after")
    def _fill_total(self) -> "University":
        if not self.total_cost_kzt:
            self.total_cost_kzt = self.tuition_kzt + self.rent_kzt + self.transport_kzt + self.living_kzt
        return self


class FilteredOut(BaseModel):
    id: str
    name: str
    reason: str


class StudentProfile(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    track: Track = Track.BOTH
    target_major: str = Field(default="Computer Science", min_length=2, max_length=120)

    ent_score: Optional[int] = Field(default=None, ge=0, le=140)
    ent_subjects: list[str] = Field(default_factory=list)
    gpa: Optional[float] = Field(default=None, ge=0, le=5)
    ielts: Optional[float] = Field(default=None, ge=0, le=9)
    sat: Optional[int] = Field(default=None, ge=0, le=1600)

    preferred_countries: list[str] = Field(default_factory=list)
    needs_scholarship: bool = False
    budget_kzt_per_year: int = Field(ge=0, le=100_000_000)

    career: Optional[str] = None
    horizon: Optional[str] = None
    work_format: Optional[str] = None

    # Клиент присылает свой локальный скоринг — ИИ аргументирует уже готовый шорт-лист.
    shortlist: list[str] = Field(default_factory=list, max_length=12)
    client_scores: dict[str, int] = Field(default_factory=dict)

    @field_validator("ent_subjects", "preferred_countries", "shortlist", mode="before")
    @classmethod
    def _clean(cls, v):
        if v is None:
            return []
        if isinstance(v, str):
            v = [v]
        return [str(x).strip() for x in v if str(x).strip()]


class Insight(BaseModel):
    university_id: str
    why: str
    risks: str
    actions: list[str] = Field(default_factory=list)


class Finding(BaseModel):
    title: str
    detail: str


class AIResult(BaseModel):
    summary: str
    strengths: list[Finding]
    limits: list[Finding]
    insights: list[Insight]
    focus_advice: str = ""

    @field_validator("strengths", "limits")
    @classmethod
    def _not_empty(cls, v: list[Finding]) -> list[Finding]:
        if not v:
            raise ValueError("список не может быть пустым")
        return v


class RecommendResponse(BaseModel):
    source: Literal["gemini", "fallback"]
    model: str
    total_universities: int
    passed_hard_filters: int
    filtered_out: list[FilteredOut]
    analyzed: list[str]
    result: AIResult
