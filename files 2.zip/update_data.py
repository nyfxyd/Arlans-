"""Заглушка парсера актуальных данных о ВУЗах.

Сейчас: валидирует universities.json и умеет мержить обновления из
локального файла патча. В будущем — реальный скрапинг сайтов ВУЗов.

Запуск:
    python -m backend.update_data --dry-run
    python -m backend.update_data --patch patches/tuition_2026.json
"""
from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path

from . import config
from .models import University

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("unipulse.update")

# TODO: каждый источник = функция fetch_<uni_id>() -> dict с полями,
# которые нужно обновить (tuition_kzt / tuition_usd / ent_passing_score).
SOURCES: dict[str, str] = {
    "kbtu": "https://kbtu.edu.kz",
    "aitu": "https://astanait.edu.kz",
    "sdu": "https://sdu.edu.kz",
}


def fetch_from_web(uni_id: str) -> dict:
    """Заглушка. Реальная реализация: httpx + selectolax/BeautifulSoup."""
    logger.info("[stub] Пропускаю парсинг %s (%s)", uni_id, SOURCES.get(uni_id, "-"))
    return {}


def load_raw(path: Path) -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))


def validate(records: list[dict]) -> list[University]:
    return [University.model_validate(item) for item in records]


def merge(records: list[dict], patch: dict[str, dict]) -> list[dict]:
    changed = 0
    for record in records:
        update = patch.get(record["id"])
        if update:
            record.update(update)
            changed += 1
    logger.info("Обновлено записей: %s", changed)
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description="Обновление данных о ВУЗах")
    parser.add_argument("--patch", type=Path, help="JSON вида {uni_id: {field: value}}")
    parser.add_argument("--dry-run", action="store_true", help="Только проверить данные")
    args = parser.parse_args()

    path = config.UNIVERSITIES_PATH
    records = load_raw(path)
    logger.info("Загружено %s записей из %s", len(records), path)

    if args.patch:
        patch = json.loads(args.patch.read_text(encoding="utf-8"))
        records = merge(records, patch)
    else:
        for record in records:
            record.update(fetch_from_web(record["id"]))

    universities = validate(records)
    logger.info("Валидация пройдена: %s ВУЗов", len(universities))

    if args.dry_run:
        logger.info("dry-run: файл не изменён")
        return

    backup = path.with_suffix(f".{datetime.now():%Y%m%d%H%M%S}.bak.json")
    backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    path.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info("Файл обновлён. Бэкап: %s", backup.name)


if __name__ == "__main__":
    main()
