"""UniPulse AI — FastAPI точка входа."""
from __future__ import annotations

import logging

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from . import config
from .ai_service import AIServiceError, analyze
from .filtering import DataError, apply_hard_rules, load_universities, pick_for_ai, reload_universities
from .models import RecommendResponse, StudentProfile, University

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("unipulse")

app = FastAPI(
    title="UniPulse AI",
    version="1.0.0",
    description="Подбор университетов и маршрут поступления для абитуриентов Казахстана.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_origin_regex=r"https://.*\.claude\.ai",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["service"])
def health() -> dict:
    return {
        "status": "ok",
        "ai_configured": bool(config.GEMINI_API_KEY),
        "model": config.GEMINI_MODEL,
        "fallback_enabled": config.ALLOW_MOCK_FALLBACK,
        "universities": len(load_universities()),
    }


@app.get("/api/universities", response_model=list[University], tags=["data"])
def list_universities(country: str | None = None, type: str | None = None) -> list[University]:
    try:
        data = load_universities()
    except DataError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if country:
        data = [u for u in data if u.country.casefold() == country.casefold()]
    if type:
        data = [u for u in data if u.type == type]
    return data


@app.post("/api/universities/reload", tags=["data"])
def reload_data() -> dict:
    try:
        return {"loaded": len(reload_universities())}
    except DataError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/api/recommend", response_model=RecommendResponse, tags=["core"])
def recommend(profile: StudentProfile) -> RecommendResponse:
    """Профиль → жёсткая фильтрация → шорт-лист → аргументация от Gemini."""
    try:
        universities = load_universities()
    except DataError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    passed, rejected = apply_hard_rules(profile, universities)
    if not passed:
        raise HTTPException(
            status_code=422,
            detail="Ни один вуз не прошёл фильтры. Увеличьте бюджет, расширьте список стран или добавьте сертификат.",
        )

    shortlist = pick_for_ai(profile, passed)

    try:
        result, source = analyze(profile, shortlist)
    except AIServiceError as exc:
        logger.error("AI failure: %s", exc)
        raise HTTPException(status_code=500, detail=f"Ошибка ИИ-сервиса: {exc}") from exc
    except Exception:
        logger.exception("Unexpected failure")
        raise HTTPException(status_code=500, detail="Внутренняя ошибка сервера. Попробуйте позже.")

    return RecommendResponse(
        source=source,
        model=config.GEMINI_MODEL,
        total_universities=len(universities),
        passed_hard_filters=len(passed),
        filtered_out=rejected[:20],
        analyzed=[u.id for u in shortlist],
        result=result,
    )
