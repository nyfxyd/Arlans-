#!/usr/bin/env bash
# Запуск бэкенда UniPulse AI
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
[ -f .env ] || cp .env.example .env
uvicorn backend.main:app --reload --port 8000
