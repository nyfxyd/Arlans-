"""Data Layer + жёсткие правила отсева (hard rules).

ИИ получает только те вузы, которые физически проходят по баллам и деньгам.
Всё «мягкое» (шансы, аргументация) остаётся за LLM и клиентским скорингом.
"""
from __future__ import annotations

import json
from functools import lru_cache

from . import config
from .models import FilteredOut, StudentProfile, Track, University


class DataError(RuntimeError):
    pass


@lru_cache(maxsize=1)
def load_universities() -> list[University]:
    path = config.UNIVERSITIES_PATH
    if not path.exists():
        raise DataError(f"Файл с данными не найден: {path}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise DataError(f"universities.json повреждён: {exc}") from exc
    return [University.model_validate(item) for item in raw]


def reload_universities() -> list[University]:
    load_universities.cache_clear()
    return load_universities()


def _norm(s: str) -> str:
    return s.strip().casefold()


def _subjects_match(profile: StudentProfile, uni: University) -> bool:
    if not uni.required_subjects:
        return True
    if not profile.ent_subjects:
        return False
    return bool({_norm(s) for s in profile.ent_subjects} & {_norm(s) for s in uni.required_subjects})


def _money(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def _check_local(p: StudentProfile, u: University) -> str | None:
    if p.ent_score is None:
        return "Не указан балл ЕНТ"
    if u.ent_passing_score and p.ent_score < u.ent_passing_score:
        return f"Балл ЕНТ {p.ent_score} ниже порога {u.ent_passing_score}"
    if not _subjects_match(p, u):
        return "Профильные предметы не совпадают: нужны " + ", ".join(u.required_subjects[:3])
    if u.ielts_min and p.ielts is not None and p.ielts < u.ielts_min:
        return f"IELTS {p.ielts} ниже требуемого {u.ielts_min}"
    if u.total_cost_kzt > p.budget_kzt_per_year and not u.scholarship:
        return f"Полная стоимость {_money(u.total_cost_kzt)} ₸/год выше бюджета и стипендий нет"
    return None


def _check_international(p: StudentProfile, u: University) -> str | None:
    if p.preferred_countries:
        if _norm(u.country) not in {_norm(c) for c in p.preferred_countries}:
            return f"Страна {u.country} не в списке предпочтений"
    if u.ielts_min:
        if not p.ielts:
            return f"Нужен IELTS от {u.ielts_min}, сертификат не указан"
        if p.ielts < u.ielts_min:
            return f"IELTS {p.ielts} ниже минимума {u.ielts_min}"
    if u.gpa_min and p.gpa is not None and p.gpa < u.gpa_min:
        return f"GPA {p.gpa} ниже минимума {u.gpa_min}"
    if u.total_cost_kzt > p.budget_kzt_per_year * 2.5 and not p.needs_scholarship:
        return f"Полная стоимость {_money(u.total_cost_kzt)} ₸/год недостижима без стипендии"
    if u.total_cost_kzt > p.budget_kzt_per_year and not u.scholarship:
        return f"Бюджета не хватает ({_money(u.total_cost_kzt)} ₸/год), стипендий нет"
    return None


def apply_hard_rules(
    profile: StudentProfile, universities: list[University] | None = None
) -> tuple[list[University], list[FilteredOut]]:
    universities = universities if universities is not None else load_universities()
    passed: list[University] = []
    rejected: list[FilteredOut] = []

    for u in universities:
        is_local = u.type == "local"
        if profile.track is Track.KZ and not is_local:
            continue
        if profile.track is Track.INTERNATIONAL and is_local:
            continue
        reason = _check_local(profile, u) if is_local else _check_international(profile, u)
        (rejected.append(FilteredOut(id=u.id, name=u.name, reason=reason)) if reason else passed.append(u))

    return passed, rejected


def pick_for_ai(profile: StudentProfile, passed: list[University], limit: int = 8) -> list[University]:
    """Шорт-лист для LLM: приоритет у вузов, которые клиент уже оценил высоко."""
    if profile.shortlist:
        by_id = {u.id: u for u in passed}
        chosen = [by_id[i] for i in profile.shortlist if i in by_id]
        if chosen:
            return chosen[:limit]
    ranked = sorted(passed, key=lambda u: profile.client_scores.get(u.id, 0), reverse=True)
    return ranked[:limit]
