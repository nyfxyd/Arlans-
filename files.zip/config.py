"""Конфигурация. Секреты — только из .env, в репозиторий не коммитятся."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent
load_dotenv(PROJECT_ROOT / ".env")

GEMINI_API_KEY: str | None = os.getenv("GEMINI_API_KEY") or None
# gemini-2.0-flash — актуальная быстрая модель. gemini-1.5-flash тоже работает.
GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_ENDPOINT: str = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
AI_TIMEOUT_SECONDS: float = float(os.getenv("AI_TIMEOUT_SECONDS", "45"))

# Без ключа сервис не падает, а отдаёт детерминированную аналитику.
ALLOW_MOCK_FALLBACK: bool = os.getenv("ALLOW_MOCK_FALLBACK", "true").lower() == "true"

UNIVERSITIES_PATH: Path = Path(os.getenv("UNIVERSITIES_PATH", BASE_DIR / "data" / "universities.json"))

USD_KZT_RATE: float = float(os.getenv("USD_KZT_RATE", "540"))
CORS_ORIGINS: list[str] = [o.strip() for o in os.getenv(
    "CORS_ORIGINS",
    "http://localhost:3000,http://localhost:5500,http://127.0.0.1:5500,http://localhost:8501,https://claude.ai"
).split(",") if o.strip()]
