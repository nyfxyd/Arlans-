# UniPulse AI

Подбор университетов и маршрут поступления для абитуриентов Казахстана.
База — 48 вузов из 17 стран. Скоринг считается в браузере (мгновенные слайдеры What-If),
аргументацию и диагностику пишет Gemini через бэкенд на FastAPI.

```
unipulse-ai/
├── backend/
│   ├── main.py            # эндпоинты, CORS, коды ошибок
│   ├── models.py          # Pydantic-схемы: профиль, вуз, строгий ответ ИИ
│   ├── filtering.py       # загрузка базы, hard rules, шорт-лист для ИИ
│   ├── ai_service.py      # промпт к Gemini, разбор JSON, офлайн-fallback
│   ├── config.py          # чтение .env
│   ├── update_data.py     # заглушка парсера актуальных цен
│   └── data/
│       ├── universities.json        # 48 вузов
│       └── build_universities.py    # генератор этого файла
├── frontend/unipulse.html # весь интерфейс: 7 экранов, 4 киллер-фичи
├── tests/smoke_test.py    # проверка логики без сети
├── run_backend.sh · run_frontend.sh
└── requirements.txt · .env.example
```

---

## Шаг 1. Ключ Gemini

Ключ выдаётся в [Google AI Studio](https://aistudio.google.com/apikey) и выглядит как `AIza...`.
Токены вида `AQ.Ab8...` — это OAuth-доступ другого сервиса, с ним Gemini вернёт 401.

```bash
cp .env.example .env
```

Откройте `.env` и впишите ключ:

```
GEMINI_API_KEY=AIza...ваш_ключ
GEMINI_MODEL=gemini-2.0-flash
```

`.env` в git не попадает (прописан в `.gitignore`). Ключ, который уже был отправлен в чат
или закоммичен, считается скомпрометированным — отзовите его и выпустите новый.

Без ключа приложение тоже работает: бэкенд отдаёт детерминированную аналитику
(`source: "fallback"`), а фронтенд — встроенный скоринг.

## Шаг 2. Бэкенд

```bash
./run_backend.sh
```

Или вручную:

```bash
python3 -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --reload --port 8000
```

Проверка: http://127.0.0.1:8000/docs — интерактивная документация.

## Шаг 3. Фронтенд

```bash
./run_frontend.sh          # http://127.0.0.1:5500/unipulse.html
```

Файл `frontend/unipulse.html` самодостаточен: можно просто открыть его двойным кликом,
залить на любой статический хостинг или встроить в Next.js как страницу.
База вузов вшита внутрь, поэтому интерфейс работает и без бэкенда — в шапке загорится
«Офлайн-режим», недоступной будет только аргументация от ИИ.

Адрес бэкенда по умолчанию `http://127.0.0.1:8000`. Поменять можно прямо в интерфейсе:
кнопка «Изменить адрес бэкенда» в плашке ошибки; значение сохраняется в браузере.

## Шаг 4. Проверка Gemini

```bash
curl http://127.0.0.1:8000/health
# {"status":"ok","ai_configured":true,"model":"gemini-2.0-flash","universities":48}
```

Живой запрос:

```bash
curl -X POST http://127.0.0.1:8000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{"track":"both","target_major":"Computer Science","ent_score":112,
       "ent_subjects":["Математика","Физика"],"gpa":4.6,"ielts":6.0,
       "budget_kzt_per_year":3000000,"career":"build",
       "shortlist":["aitu","kbtu","agh"]}'
```

В ответе поле `source`: `gemini` — ключ работает, `fallback` — ключ не задан или Gemini недоступен
(причина будет в логах uvicorn).

Логика без сети проверяется так:

```bash
python -m tests.smoke_test
```

---

## API

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/health` | статус, модель, число вузов |
| GET | `/api/universities?country=Польша&type=international` | база с фильтрами |
| POST | `/api/universities/reload` | перечитать JSON после парсера |
| POST | `/api/recommend` | профиль → фильтры → шорт-лист → разбор от Gemini |

Как устроен `/api/recommend`: клиент присылает профиль, свой локальный шорт-лист
(`shortlist`) и посчитанные проценты (`client_scores`). Бэкенд прогоняет жёсткие правила,
берёт до восьми вузов и просит Gemini объяснить каждый, назвать риск и действия.
Модель не решает, кто проходит по деньгам и баллам — это делает детерминированный код.

Ошибки: 422 — профиль невалиден или ни один вуз не прошёл фильтры; 500 — проблема Gemini
с человекочитаемым текстом (таймаут, лимит, неверный ключ). При `ALLOW_MOCK_FALLBACK=true`
сбой Gemini не роняет ответ, а подменяется офлайн-аналитикой.

## Данные

Правьте `backend/data/universities.json` напрямую или генератор
`backend/data/build_universities.py` (одна строка `L(...)` — один вуз), затем:

```bash
python backend/data/build_universities.py
curl -X POST http://127.0.0.1:8000/api/universities/reload
```

Чтобы обновлённая база попала во фронтенд, пересоберите вшитый массив:

```bash
python - <<'EOF'
import json, pathlib, re
db = json.load(open('backend/data/universities.json', encoding='utf-8'))
p = pathlib.Path('frontend/unipulse.html'); html = p.read_text(encoding='utf-8')
p.write_text(re.sub(r'const DB = .*?;\n', 'const DB = ' + json.dumps(db, ensure_ascii=False) + ';\n', html, count=1, flags=re.S), encoding='utf-8')
EOF
```

Поля вуза: пороги (`ent_passing_score`, `ielts_min`, `sat_recommended`, `gpa_min`),
деньги (`tuition_kzt`, `rent_kzt`, `transport_kzt`, `living_kzt`), `scholarship`, `dorm`,
`vibe` (теги среды), `teaching` (практика / наука / индустрия),
`weights` (насколько сильно для этого вуза значат предметы, баллы, бюджет и среда),
`deadlines` (подача, стипендия, документы — из них строится Roadmap).

## Что где настраивается

| Задача | Файл |
|---|---|
| Модель, таймаут, CORS, курс доллара | `backend/config.py` и `.env` |
| Формулировки промпта | `ai_service.py`, константа `SYSTEM_PROMPT` |
| Правила отсева | `filtering.py`, функции `_check_local` / `_check_international` |
| Веса скоринга | функция `score()` в `frontend/unipulse.html` + поле `weights` у вуза |
| Границы Safety / Target / Reach | `categoryOf()` там же |
| Тексты подсказок на экранах | объект `HINTS` в начале скрипта |

## Что хранится в браузере

`localStorage`, ключ `unipulse.v1`: профиль, отмеченные задачи, вузы в сравнении,
положения слайдеров симулятора, адрес бэкенда и последний открытый экран.
Кнопка «Сбросить все данные» на экране «Фокус» очищает всё. Запись обёрнута в try/catch,
поэтому в приватном режиме приложение работает, просто без сохранения.

## Дальше

1. Кэш ответов Gemini по хэшу профиля (Redis) — один профиль не должен стоить нового вызова модели.
2. PostgreSQL вместо JSON: менять только `load_universities()`.
3. Реальный парсер цен в `update_data.py` — каркас с бэкапом, валидацией и `--patch` уже готов.
4. Аккаунты и общий доступ к плану для родителей и школьного координатора.
