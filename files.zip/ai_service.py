"""AI Engine: промпт к Gemini, строгий разбор JSON, детерминированный fallback."""
from __future__ import annotations

import json
import logging
import re
from typing import Any

import httpx
from pydantic import ValidationError

from . import config
from .models import AIResult, StudentProfile, University

logger = logging.getLogger("unipulse.ai")
_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


class AIServiceError(RuntimeError):
    """Таймаут, лимит, неверный ключ или невалидный JSON от модели."""


SYSTEM_PROMPT = """\
Ты — приёмный консультант UniPulse AI. Твой собеседник — школьник из Казахстана и его родители.
Тебе дают профиль абитуриента и шорт-лист вузов, уже прошедших проверку по баллам и деньгам.

Задачи:
1) объяснить по каждому вузу, почему он подходит именно этому абитуриенту (ссылайся на его цифры),
2) назвать главный риск по каждому варианту,
3) дать 2-3 конкретных действия по каждому вузу,
4) собрать общий вывод, сильные стороны и ограничения профиля.

ПРАВИЛА:
- Отвечай ТОЛЬКО валидным JSON-объектом. Без markdown, без ```json, без текста вокруг.
- university_id бери строго из предоставленного списка, вузы не выдумывай.
- Язык — русский, тон спокойный и конкретный, без пафоса и общих советов.
- Цифры в аргументации — только из входных данных.
- Каждое поле why и risks — 1-2 предложения.

СХЕМА:
{
  "summary": "2-3 предложения: общий вывод по абитуриенту",
  "strengths": [{"title": "коротко", "detail": "объяснение с цифрами"}],
  "limits":    [{"title": "коротко", "detail": "объяснение с цифрами"}],
  "insights": [
    {"university_id":"id","why":"почему подходит","risks":"главный риск","actions":["действие","действие"]}
  ],
  "focus_advice": "одно предложение: что сделать на этой неделе"
}
"""


def _profile_payload(p: StudentProfile) -> dict[str, Any]:
    return {
        "имя": p.name,
        "трек": p.track.value,
        "специальность": p.target_major,
        "балл_ЕНТ": p.ent_score,
        "профильные_предметы": p.ent_subjects,
        "GPA": p.gpa,
        "IELTS": p.ielts,
        "SAT": p.sat,
        "страны": p.preferred_countries,
        "нужен_грант": p.needs_scholarship,
        "бюджет_тенге_в_год": p.budget_kzt_per_year,
        "карьерный_трек": p.career,
        "горизонт_5_лет": p.horizon,
        "формат_работы": p.work_format,
    }


def _uni_payload(u: University, p: StudentProfile) -> dict[str, Any]:
    return {
        "id": u.id,
        "name": u.name,
        "city": u.city,
        "country": u.country,
        "порог_ЕНТ": u.ent_passing_score,
        "IELTS_min": u.ielts_min,
        "SAT": u.sat_recommended,
        "обучение_тенге": u.tuition_kzt,
        "полная_стоимость_тенге": u.total_cost_kzt,
        "стипендии": u.scholarship,
        "общежитие": u.dorm,
        "среда": u.vibe,
        "качество": u.teaching.model_dump(),
        "дедлайн_подачи": u.deadlines.application,
        "совпадение_по_версии_клиента": p.client_scores.get(u.id),
    }


def build_prompt(profile: StudentProfile, unis: list[University]) -> str:
    return (
        "ПРОФИЛЬ:\n" + json.dumps(_profile_payload(profile), ensure_ascii=False, indent=2)
        + "\n\nШОРТ-ЛИСТ ВУЗОВ:\n"
        + json.dumps([_uni_payload(u, profile) for u in unis], ensure_ascii=False, indent=2)
        + "\n\nВерни JSON строго по схеме из системной инструкции."
    )


def _strip(text: str) -> str:
    cleaned = _FENCE.sub("", text.strip())
    a, b = cleaned.find("{"), cleaned.rfind("}")
    return cleaned[a:b + 1] if a != -1 and b > a else cleaned


def parse_ai_json(raw: str) -> AIResult:
    try:
        payload = json.loads(_strip(raw))
    except json.JSONDecodeError as exc:
        raise AIServiceError(f"Модель вернула невалидный JSON: {exc}") from exc
    try:
        return AIResult.model_validate(payload)
    except ValidationError as exc:
        details = "; ".join(f"{'.'.join(map(str, e['loc']))}: {e['msg']}" for e in exc.errors()[:4])
        raise AIServiceError(f"JSON не соответствует схеме: {details}") from exc


def _call_gemini(prompt: str) -> str:
    url = config.GEMINI_ENDPOINT.format(model=config.GEMINI_MODEL)
    body = {
        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.4, "responseMimeType": "application/json", "maxOutputTokens": 4096},
    }
    try:
        with httpx.Client(timeout=config.AI_TIMEOUT_SECONDS) as client:
            r = client.post(url, params={"key": config.GEMINI_API_KEY}, json=body)
    except httpx.TimeoutException as exc:
        raise AIServiceError("ИИ-сервис не ответил вовремя. Попробуйте ещё раз.") from exc
    except httpx.HTTPError as exc:
        raise AIServiceError(f"Сеть недоступна для ИИ-сервиса: {exc}") from exc

    if r.status_code == 429:
        raise AIServiceError("Превышен лимит запросов к Gemini. Подождите минуту.")
    if r.status_code in (401, 403):
        raise AIServiceError("Ключ Gemini неверный или не активирован. Проверьте GEMINI_API_KEY в .env.")
    if r.status_code >= 400:
        raise AIServiceError(f"Gemini вернул {r.status_code}: {r.text[:200]}")

    try:
        parts = r.json()["candidates"][0]["content"]["parts"]
        return "".join(p.get("text", "") for p in parts)
    except (KeyError, IndexError, ValueError) as exc:
        raise AIServiceError("Неожиданный формат ответа Gemini.") from exc


def analyze(profile: StudentProfile, unis: list[University]) -> tuple[AIResult, str]:
    """Возвращает (результат, источник: 'gemini' | 'fallback')."""
    if not unis:
        raise AIServiceError("Пустой шорт-лист: ни один вуз не прошёл жёсткие фильтры.")

    if not config.GEMINI_API_KEY:
        if not config.ALLOW_MOCK_FALLBACK:
            raise AIServiceError("GEMINI_API_KEY не задан в .env")
        logger.warning("Ключ не задан — отдаю детерминированную аналитику.")
        return build_fallback(profile, unis), "fallback"

    prompt = build_prompt(profile, unis)
    last: AIServiceError | None = None
    for attempt in (1, 2):
        try:
            extra = "" if attempt == 1 else (
                "\n\nПРЕДЫДУЩИЙ ОТВЕТ БЫЛ НЕВАЛИДЕН. Верни ровно один JSON-объект по схеме, без markdown."
            )
            return parse_ai_json(_call_gemini(prompt + extra)), "gemini"
        except AIServiceError as exc:
            last = exc
            logger.warning("Попытка %s: %s", attempt, exc)
            if any(w in str(exc) for w in ("лимит", "Ключ", "Сеть")):
                break

    if config.ALLOW_MOCK_FALLBACK:
        logger.error("Gemini недоступен (%s) — отдаю fallback.", last)
        return build_fallback(profile, unis), "fallback"
    raise last  # type: ignore[misc]


# --------------------------------------------------------------------------
# Детерминированная аналитика: работает без ключа и когда Gemini недоступен.
# --------------------------------------------------------------------------
def _m(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def build_fallback(p: StudentProfile, unis: list[University]) -> AIResult:
    strengths, limits = [], []

    if p.ent_score and p.ent_score >= 110:
        fits = sum(1 for u in unis if u.ent_passing_score and p.ent_score >= u.ent_passing_score)
        strengths.append({"title": "Грантовый коридор открыт",
                          "detail": f"{p.ent_score} баллов ЕНТ проходят порог {fits} вузов из шорт-листа."})
    elif p.ent_score:
        limits.append({"title": "Балл ЕНТ — главный рычаг",
                       "detail": f"{p.ent_score} баллов: до порога сильных технических вузов не хватает примерно {max(0, 110 - p.ent_score)}."})

    if p.ielts and p.ielts >= 6.5:
        strengths.append({"title": "Язык не ограничивает выбор",
                          "detail": f"IELTS {p.ielts} снимает языковой барьер во всех зарубежных вариантах подборки."})
    elif p.ielts:
        limits.append({"title": "IELTS ниже планки топ-вузов",
                       "detail": f"{p.ielts} против 6.5 у ведущих программ. Разница в 0.5 балла заметно двигает шансы."})
    else:
        limits.append({"title": "Нет языкового сертификата",
                       "detail": "Без IELTS доступны только программы на русском и казахском."})

    affordable = sum(1 for u in unis if u.total_cost_kzt <= p.budget_kzt_per_year)
    if affordable >= len(unis) / 2:
        strengths.append({"title": "Бюджет покрывает большинство сценариев",
                          "detail": f"{affordable} из {len(unis)} вузов укладываются в {_m(p.budget_kzt_per_year)} ₸ в год со всеми расходами."})
    else:
        limits.append({"title": "Бюджет — узкое место",
                       "detail": f"Полностью покрываются только {affordable} из {len(unis)}. Остальные требуют стипендии."})

    if p.career:
        strengths.append({"title": "Карьерный трек определён",
                          "detail": f"Профориентация указывает на трек «{p.career}» — он учтён в ранжировании."})
    if not strengths:
        strengths.append({"title": "Профиль заполнен", "detail": "Данных достаточно для первичного подбора."})
    if not limits:
        limits.append({"title": "Критичных ограничений нет", "detail": "Держите темп подготовки и следите за дедлайнами."})

    insights = [{
        "university_id": u.id,
        "why": u.why or f"{u.name} проходит по вашим баллам и бюджету.",
        "risks": ("Конкурс на грантовые места и сроки подачи документов."
                  if u.type == "local" else
                  f"Языковой сертификат и полная стоимость {_m(u.total_cost_kzt)} ₸ в год."),
        "actions": [f"Проверить дедлайн подачи: {u.deadlines.application}",
                    f"Изучить условия: {u.scholarship}" if u.scholarship else "Собрать транскрипт и рекомендации"],
    } for u in unis]

    top = unis[0]
    return AIResult.model_validate({
        "summary": (f"Офлайн-режим без Gemini: аналитика собрана по правилам. В шорт-листе {len(unis)} вузов, "
                    f"ведущий вариант — {top.name} ({top.city}). Добавьте GEMINI_API_KEY в .env для развёрнутого разбора."),
        "strengths": strengths[:4],
        "limits": limits[:3],
        "insights": insights,
        "focus_advice": f"На этой неделе: проверить требования {top.name} и записаться на пробный тест.",
    })
