"""Слияние баз: 48 кураторских вузов (полные данные) + 332 из universities_database v2.0.

Правило: ничего не выдумываем. Нет данных в источнике → null, а интерфейс
показывает «нет данных» вместо штрафа в скоринге.
"""
import json, re, unicodedata
from pathlib import Path

SRC_NEW = Path("/mnt/user-data/uploads/universities_database__2_.json")
SRC_OLD = Path("/mnt/user-data/outputs/unipulse-ai/backend/data/universities.json")
OUT = Path("/mnt/user-data/outputs/unipulse-ai/backend/data/universities.json")

# Курсы к тенге, сентябрь 2026 (ориентировочные, вынесены в одно место).
FX = {
    "USD": 540, "EUR": 592, "GBP": 690, "CHF": 640, "CAD": 392, "AUD": 356, "NZD": 320,
    "JPY": 3.6, "CNY": 75, "HKD": 69, "KRW": 0.39, "SGD": 415, "TWD": 17, "MYR": 122,
    "SEK": 55, "NOK": 51, "DKK": 79, "PLN": 143, "CZK": 24, "HUF": 1.5, "RON": 119,
    "TRY": 13, "AED": 147, "SAR": 144, "QAR": 148, "ILS": 145, "INR": 6.2, "RUB": 6.5,
    "ZAR": 30, "BRL": 100, "MXN": 28, "CLP": 0.56, "THB": 16, "IDR": 0.033, "KZT": 1,
}

FLAGS = {
    "US": "🇺🇸", "GB": "🇬🇧", "DE": "🇩🇪", "CN": "🇨🇳", "CA": "🇨🇦", "FR": "🇫🇷", "IT": "🇮🇹",
    "ES": "🇪🇸", "JP": "🇯🇵", "AU": "🇦🇺", "NL": "🇳🇱", "CH": "🇨🇭", "SE": "🇸🇪", "KR": "🇰🇷",
    "SG": "🇸🇬", "HK": "🇭🇰", "BE": "🇧🇪", "AT": "🇦🇹", "DK": "🇩🇰", "NO": "🇳🇴", "FI": "🇫🇮",
    "IE": "🇮🇪", "PL": "🇵🇱", "CZ": "🇨🇿", "HU": "🇭🇺", "TR": "🇹🇷", "AE": "🇦🇪", "SA": "🇸🇦",
    "MY": "🇲🇾", "NZ": "🇳🇿", "IL": "🇮🇱", "IN": "🇮🇳", "PT": "🇵🇹", "GR": "🇬🇷", "KZ": "🇰🇿",
    "TW": "🇹🇼", "BR": "🇧🇷", "MX": "🇲🇽", "ZA": "🇿🇦", "RU": "🇷🇺", "TH": "🇹🇭",
}

# Ориентир стоимости жизни в год (₸), если в источнике нет cost_of_living_monthly.
LIVING_BASE = {
    "US": 3_600_000, "GB": 3_400_000, "CH": 4_200_000, "SG": 3_600_000, "HK": 3_500_000,
    "AU": 3_200_000, "CA": 3_000_000, "NO": 3_400_000, "DK": 3_200_000, "SE": 2_900_000,
    "NL": 3_000_000, "IE": 3_100_000, "DE": 3_000_000, "FR": 2_800_000, "AT": 2_800_000,
    "BE": 2_700_000, "FI": 2_700_000, "IT": 2_500_000, "ES": 2_300_000, "JP": 2_900_000,
    "KR": 2_600_000, "TW": 2_000_000, "CN": 2_100_000, "AE": 2_900_000, "SA": 2_300_000,
    "IL": 3_000_000, "PT": 2_100_000, "GR": 1_900_000, "PL": 1_900_000, "CZ": 2_000_000,
    "HU": 1_900_000, "TR": 1_500_000, "MY": 1_700_000, "IN": 1_100_000, "NZ": 2_900_000,
    "BR": 1_600_000, "MX": 1_500_000, "ZA": 1_400_000, "TH": 1_500_000, "RU": 1_500_000,
}
LIVING_DEFAULT = 2_400_000

CAREER_HINTS = {
    "build": ["technolog", "technical", "engineering", "polytech", "institute of technology", "tech"],
    "research": ["university", "universit", "research", "science", "college"],
    "business": ["business", "economic", "management", "commerce", "finance"],
    "care": ["medical", "health", "medicine"],
}


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").lower()
    s = re.sub(r"\(.*?\)", " ", s)
    s = re.sub(r"[^a-z0-9а-яё ]+", " ", s)
    return " ".join(s.split())


def slug(s: str) -> str:
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", norm(s))).strip("-")[:48]


def to_kzt(amount, currency):
    if amount is None:
        return None
    rate = FX.get((currency or "USD").upper())
    if not rate:
        return None
    return int(round(amount * rate, -4))


def main_program(uni):
    progs = uni.get("programs") or []
    bach = [p for p in progs if (p.get("degree_level") or "") == "Bachelor"]
    return (bach or progs or [None])[0]


def careers_for(uni):
    text = norm(uni["university_name"])
    out = [k for k, words in CAREER_HINTS.items() if any(w in text for w in words)]
    return out or []


def vibe_for(uni, prog, country):
    """Только факты из источника — никаких выдуманных описаний среды."""
    v = []
    lang = (prog or {}).get("language_of_instruction")
    if lang:
        v.append(f"Язык обучения: {lang}")
    if uni.get("acceptance_rate") is not None:
        v.append(f"Принимают {uni['acceptance_rate']}% заявок")
    if uni.get("financial_aid_policy"):
        v.append(f"Финпомощь: {uni['financial_aid_policy']}")
    pw = (country or {}).get("post_study_work_visa")
    if pw:
        v.append("После выпуска: " + (pw[:70] + "…" if len(pw) > 70 else pw))
    return v[:4]


def why_for(uni, prog, country):
    fin = (prog or {}).get("finances") or {}
    for key in ("full_ride_conditions", "full_tuition_conditions", "tuition_note"):
        val = fin.get(key)
        if val:
            return val[:230]
    if uni.get("notes"):
        return uni["notes"][:230]
    pw = (country or {}).get("post_study_work_visa")
    if pw:
        return f"{uni['university_name']}, {uni.get('city') or ''}. Рабочая виза после выпуска: {pw[:120]}"
    return f"{uni['university_name']} — данные о программе уточняются в источнике."


def convert(uni, countries_by_code):
    prog = main_program(uni)
    code = uni.get("country_code") or ""
    country = countries_by_code.get(code, {})
    req = (prog or {}).get("requirements") or {}
    acad, lang_req = req.get("academic") or {}, req.get("language") or {}
    fin = (prog or {}).get("finances") or {}
    dl = (prog or {}).get("deadlines") or {}

    tuition = to_kzt(fin.get("tuition_fee_annual"), fin.get("currency"))
    col_month = to_kzt(uni.get("cost_of_living_monthly"), uni.get("cost_of_living_currency") or country.get("default_currency"))
    cost_estimated = col_month is None
    living_total = col_month * 12 if col_month else LIVING_BASE.get(code, LIVING_DEFAULT)

    rent = int(round(living_total * 0.45, -4))
    living = int(round(living_total * 0.40, -4))
    transport = int(round(living_total * 0.15, -4))

    sat_range = acad.get("sat_range_25_75") or []
    sat = acad.get("sat_min_score") or (sat_range[0] if sat_range else None)

    scholarship = fin.get("full_ride_conditions") or fin.get("full_tuition_conditions") or uni.get("financial_aid_policy") or ""

    return {
        "id": uni["university_id"],
        "name": uni["university_name"],
        "city": uni.get("city") or "",
        "country": uni.get("country_ru") or country.get("country_name_ru") or uni.get("country") or "",
        "flag": FLAGS.get(code, "🏳️"),
        "type": "local" if code == "KZ" else "international",
        "majors": ["Все направления"] if "все направления" in norm((prog or {}).get("program_name", "")) else [(prog or {}).get("program_name", "")[:60]],
        "careers": careers_for(uni),
        "vibe": vibe_for(uni, prog, country),
        "why": why_for(uni, prog, country),
        "ent_passing_score": acad.get("ent_min_score"),
        "required_subjects": acad.get("ent_subjects") or [],
        "ielts_min": lang_req.get("ielts_overall_min"),
        "sat_recommended": sat,
        "gpa_min": acad.get("gpa_min"),
        "tuition_kzt": tuition if tuition is not None else 0,
        "tuition_known": tuition is not None,
        "rent_kzt": rent,
        "transport_kzt": transport,
        "living_kzt": living,
        "total_cost_kzt": (tuition or 0) + rent + living + transport,
        "cost_estimated": cost_estimated or tuition is None,
        "scholarship": scholarship,
        "dorm": None,
        "teaching": None,
        "weights": {"subjects": 1.0, "scores": 1.0, "budget": 1.0, "vibe": 1.0},
        "deadlines": {
            "application": dl.get("regular_deadline"),
            "early": dl.get("early_deadline"),
            "scholarship": dl.get("scholarship_deadline"),
            "documents": None,
        },
        "website": uni.get("official_website_url") or (prog or {}).get("official_website_url"),
        "acceptance_rate": uni.get("acceptance_rate"),
        "application_fee": (f"{uni['application_fee']} {uni.get('application_fee_currency') or ''}".strip()
                            if uni.get("application_fee") is not None else None),
        "lang": (prog or {}).get("language_of_instruction"),
        "ielts_note": lang_req.get("ielts_note"),
        "gpa_note": acad.get("gpa_note"),
        "sat_note": acad.get("sat_note"),
        "lor_count": ((req.get("documents") or {}).get("lor_count")),
        "interview": ((req.get("documents") or {}).get("interview_status")),
        "visa": country.get("visa_type"),
        "post_study": country.get("post_study_work_visa"),
        "blocked_account": country.get("blocked_account_amount"),
        "source": "db2",
        "data_status": uni.get("data_status") or "partial",
    }


def main():
    raw = json.loads(SRC_NEW.read_text(encoding="utf-8"))
    countries = {c["country_code"]: c for c in raw["countries"]}
    curated = json.loads(SRC_OLD.read_text(encoding="utf-8"))

    for c in curated:
        c.setdefault("source", "curated")
        c.setdefault("data_status", "complete")
        c.setdefault("tuition_known", True)
        c.setdefault("cost_estimated", False)
        c["deadlines"].setdefault("early", None)

    cur_keys = [(norm(c["name"]), c) for c in curated]
    merged, dupes = list(curated), 0

    for uni in raw["universities"]:
        conv = convert(uni, countries)
        n = norm(conv["name"])
        hit = None
        for key, c in cur_keys:
            if c["country"] != conv["country"]:
                continue
            if key == n or (len(key) > 8 and (key in n or n in key)):
                hit = c
                break
        if hit:  # кураторская запись точнее — добираем из новой только недостающее
            dupes += 1
            for field in ("website", "acceptance_rate", "application_fee", "lang",
                          "visa", "post_study", "blocked_account", "lor_count", "interview"):
                if conv.get(field) and not hit.get(field):
                    hit[field] = conv[field]
            if conv["deadlines"].get("early") and not hit["deadlines"].get("early"):
                hit["deadlines"]["early"] = conv["deadlines"]["early"]
            continue
        merged.append(conv)

    seen, out = set(), []
    for u in merged:
        uid = u["id"]
        if uid in seen:
            uid = f"{uid}-{slug(u['city'])}"
            u["id"] = uid
        seen.add(uid)
        out.append(u)

    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

    countries_out = sorted({u["country"] for u in out})
    print(f"итого вузов: {len(out)} (кураторских {len(curated)}, новых {len(out)-len(curated)}, дублей слито {dupes})")
    print(f"стран: {len(countries_out)}")
    print("с IELTS:", sum(1 for u in out if u.get("ielts_min")))
    print("с дедлайном подачи:", sum(1 for u in out if (u.get('deadlines') or {}).get('application')))
    print("с известной стоимостью обучения:", sum(1 for u in out if u.get("tuition_known")))

    # Визовые карточки по странам — из справочника стран, без выдумок.
    visa = [{
        "country": c.get("country_name_ru"),
        "flag": FLAGS.get(c["country_code"], "🏳️"),
        "visa_type": c.get("visa_type"),
        "post_study": c.get("post_study_work_visa"),
        "finances": c.get("blocked_account_amount"),
        "universities": c.get("university_count"),
    } for c in raw["countries"]]
    Path("/home/claude/visa_from_db.json").write_text(json.dumps(visa, ensure_ascii=False), encoding="utf-8")
    print("визовых справок:", len(visa))


if __name__ == "__main__":
    main()
