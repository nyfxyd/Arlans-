#!/usr/bin/env bash
# Раздача фронтенда на http://127.0.0.1:5500/unipulse.html
cd "$(dirname "$0")/frontend"
python3 -m http.server 5500
